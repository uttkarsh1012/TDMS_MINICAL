<?php

$lang['stripe-integration']['Select Default Payment Gateway'] = 'Selecione o gateway de pagamento padrão';
$lang['stripe-integration']['Public Key'] = 'Chave pública';
$lang['stripe-integration']['Secret Key'] = 'Chave secreta';
$lang['stripe-integration']['Update'] = 'Atualizar';
$lang['stripe-integration']['Payment Gateway Settings'] = 'Configurações de gateway de pagamento';
$lang['stripe-integration']['Current Payment Gateway'] = 'Gateway de pagamento atual';
$lang['stripe-integration']['Please fill all fields'] = 'Por favor preencha todos os campos';
$lang['stripe-integration']['Settings updated.'] = 'Configurações atualizadas.';
$lang['stripe-integration'][''] = '';

$lang['stripe-integration']['Payment Gateway Report'] = 'Payment Gateway Report';
$lang['stripe-integration']['All Companies'] = 'All Companies';
$lang['stripe-integration']['Company Name'] = 'Company Name';
$lang['stripe-integration']['Date'] = 'Date';
$lang['stripe-integration']['Booking ID'] = 'Booking ID';
$lang['stripe-integration']['Charge Type'] = 'Charge Type';
$lang['stripe-integration']['Transaction ID'] = 'Transaction ID';
$lang['stripe-integration']['Success Status'] = 'Success Status';
$lang['stripe-integration']['Amount charged'] = 'Amount charged';
$lang['stripe-integration']['Bank Fee 5%'] = 'Bank Fee 5%';
$lang['stripe-integration']['Total amount'] = 'Total amount';
$lang['stripe-integration']['Total'] = 'Total';
$lang['stripe-integration']['Charge Back'] = 'Charge Back';
$lang['stripe-integration']['Amount Payable'] = 'Amount Payable';
?>