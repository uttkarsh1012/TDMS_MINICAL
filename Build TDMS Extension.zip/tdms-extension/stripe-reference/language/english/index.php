<?php

$lang['stripe-integration']['Select Default Payment Gateway'] = 'Select Default Payment Gateway';
$lang['stripe-integration']['Public Key'] = 'Public Key';
$lang['stripe-integration']['Secret Key'] = 'Secret Key';
$lang['stripe-integration']['Update'] = 'Update';
$lang['stripe-integration']['Payment Gateway Settings'] = 'Payment Gateway Settings';
$lang['stripe-integration']['Current Payment Gateway'] = 'Current Payment Gateway';
$lang['stripe-integration']['Please fill all fields'] = 'Please fill all fields';
$lang['stripe-integration']['Settings updated.'] = 'Settings updated.';
$lang['stripe-integration'][''] = '';

$lang['stripe-integration']['Payment Gateway Report'] = 'Payment Gateway Report';
$lang['stripe-integration']['All Companies'] = 'All Companies';
$lang['stripe-integration']['Company Name'] = 'Company Name';
$lang['stripe-integration']['Date'] = 'Date';
$lang['stripe-integration']['Booking ID'] = 'Booking ID';
$lang['stripe-integration']['Charge Type'] = 'Charge Type';
$lang['stripe-integration']['Transaction ID'] = 'Transaction ID';
$lang['stripe-integration']['Success Status'] = 'Success Status';
$lang['stripe-integration']['Amount charged'] = 'Amount charged';
$lang['stripe-integration']['Bank Fee 5%'] = 'Bank Fee 5%';
$lang['stripe-integration']['Total amount'] = 'Total amount';
$lang['stripe-integration']['Total'] = 'Total';
$lang['stripe-integration']['Charge Back'] = 'Charge Back';
$lang['stripe-integration']['Amount Payable'] = 'Amount Payable';
$lang['stripe-integration']['Add Payment'] = 'Add Payment';

?>