<?php

$lang['minical-extension-boilerplate']['booking list'] = '예약 목록';
$lang['minical-extension-boilerplate']['booking_id'] = '예약 ID';
$lang['minical-extension-boilerplate']['room_number'] = '방 번호';
$lang['minical-extension-boilerplate']['check_in_date'] = '체크인 날짜';
$lang['minical-extension-boilerplate']['check_out_date'] = '체크 아웃 날짜';
$lang['minical-extension-boilerplate']['customer_name'] = '고객 이름';
$lang['minical-extension-boilerplate']['no_bookings_found'] = '예약을 찾을 수 없습니다';
$lang['minical-extension-boilerplate']['Thank You Form miniCal'] = '감사 양식 miniCal';


?>
