<?php

$lang['tdms_payment_gateway'] = 'TDMS Payment Gateway';
$lang['tdms_merchant_id'] = 'Merchant ID';
$lang['tdms_api_passcode'] = 'API Access Passcode';
$lang['tdms_profile_passcode'] = 'Profile API Passcode';
$lang['tdms_test_mode'] = 'Test Mode';
$lang['tdms_enable_tokenization'] = 'Enable Tokenization';
$lang['tdms_settings_saved'] = 'TDMS settings saved successfully';
$lang['tdms_connection_success'] = 'Connection to TDMS successful';
$lang['tdms_connection_failed'] = 'Connection to TDMS failed';
$lang['tdms_payment_success'] = 'Payment processed successfully';
$lang['tdms_payment_failed'] = 'Payment processing failed';
$lang['tdms_refund_success'] = 'Refund processed successfully';
$lang['tdms_refund_failed'] = 'Refund processing failed';