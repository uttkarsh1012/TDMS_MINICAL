<?php

$lang['tdms_payment_gateway'] = 'Gateway de Pagamento TDMS';
$lang['tdms_merchant_id'] = 'ID do Comerciante';
$lang['tdms_api_passcode'] = 'Senha de Acesso à API';
$lang['tdms_profile_passcode'] = 'Senha da API de Perfil';
$lang['tdms_test_mode'] = 'Modo de Teste';
$lang['tdms_enable_tokenization'] = 'Ativar Tokenização';
$lang['tdms_settings_saved'] = 'Configurações TDMS salvas com sucesso';
$lang['tdms_connection_success'] = 'Conexão com TDMS bem-sucedida';
$lang['tdms_connection_failed'] = 'Falha na conexão com TDMS';
$lang['tdms_payment_success'] = 'Pagamento processado com sucesso';
$lang['tdms_payment_failed'] = 'Falha no processamento do pagamento';
$lang['tdms_refund_success'] = 'Reembolso processado com sucesso';
$lang['tdms_refund_failed'] = 'Falha no processamento do reembolso';