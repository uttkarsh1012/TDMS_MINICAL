<?php

function custom_helper($data){
    // start writing code here   
}