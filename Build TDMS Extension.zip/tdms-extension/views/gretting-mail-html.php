<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title><?php echo $company_name; ?></title>
    <style type="text/css">
        h2 {font: bold 16px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;}
        h3 {font: 16px Arial, Helvetica, sans-serif; margin: 0; color: black;}
        .group {border: 1px solid black; padding: 10px; }
        #customer-name, #company-name {font-weight: bold; }
    </style>
</head>
<body>
<div style="max-width: 600px;">

    <h3>Dear <?php echo $company_name;?></h3><br/>
    <h4> <?php echo $content; ?> </h4>
    <h4> <?php echo $content1; ?> </h4>


</div>
</body>
</html>
