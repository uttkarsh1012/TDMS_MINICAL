<?php

$autoload['libraries'] = array();
$autoload['helper'] = array();
$autoload['model'] = array();