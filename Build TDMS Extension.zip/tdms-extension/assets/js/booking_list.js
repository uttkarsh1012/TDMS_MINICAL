//write js code here
$(document).ready(function () {
    $('#booling_list').DataTable();
    $('#customer_list').DataTable();
});
